create
    definer = root@localhost procedure ChangeDataToHistory(IN ProcessVersionInstanceGuid varchar(50))
BEGIN

	DECLARE

		T_ProcessVersionInstanceGuid VARCHAR (50);



DECLARE

	done INT DEFAULT 0;





DECLARE

	CURSOR_POINT CURSOR FOR SELECT

		PROCESSVERSIONINSTANCEGUID

	FROM

		workflow_pvi

	WHERE

		MAINPVIGUID = ProcessVersionInstanceGuid;







DECLARE

	CONTINUE HANDLER FOR SQLSTATE '02000'

SET done = 1;





OPEN CURSOR_POINT;





FETCH NEXT

FROM

	CURSOR_POINT INTO T_ProcessVersionInstanceGuid;





REPEAT



IF NOT Done THEN

	 insert into Workflow_Activity_Instance_His

      (Row_ID,

       ActivityGuid,

       ActivityInstanceGuid,

       SUBPROCESSVERSIONINSTANCEGUID,

       Status,

       StartDate,

       ENDTIME,

       TERMINATEDATE,

       IS_OVERTIME,

       ROLLBACKTAG,

       ACTIVITYINSTANCENAME,

       ProcessVersionGuid,

       ProcessVersionInstanceGuid,

       Note)

      Select Row_ID,

             ActivityGuid,

             ActivityInstanceGuid,

             SUBPROCESSVERSIONINSTANCEGUID,

             Status,

             StartDate,

             ENDTIME,

             TERMINATEDATE,

             IS_OVERTIME,

             ROLLBACKTAG,

             ACTIVITYINSTANCENAME,

             ProcessVersionGuid,

             ProcessVersionInstanceGuid,

             Note

        From Workflow_Activity_Instance

       where ProcessVersionInstanceGuid =

             T_ProcessVersionInstanceGuid;

    Delete from Workflow_Activity_Instance

     where ProcessVersionInstanceGuid =

           T_ProcessVersionInstanceGuid;

  

   insert into Workflow_Pvi_Mistablerow_His

    (Row_ID,

     MATERIALINSTANCEGUID,

     TABLEID,

     SQL_TABLENAME,

     MISROWGUID,

     PVIGUID,

     MISTABLESETINSTANCEGUID)

    Select Row_ID,

           MATERIALINSTANCEGUID,

           TABLEID,

           SQL_TABLENAME,

           MISROWGUID,

           PVIGUID,

           MISTABLESETINSTANCEGUID

      From Workflow_Pvi_Mistablerow

     where  PVIGUID = T_ProcessVersionInstanceGuid;

  Delete from Workflow_Pvi_Mistablerow

   where  PVIGUID = T_ProcessVersionInstanceGuid;



    insert into Workflow_PVI_Material_His

      (Row_ID,

       MATERIALINSTANCEGUID,

       MATERIALINSTANCENAME,

       ADDDATE,

       IS_DEFINED,

       ADDINWORKITEMGUID,

       ADDUSERGUID,

       PROCESSVERSIONINSTANCEGUID,

       MATERIALGUID,

       MATERIALNAME,

       SOURCE,

       TYPE,

       ATTACHSTORAGEINFOGROUPGUID,

       PAGEURL_READANDWRITE,

       PAGEURL_READ,

       PAGEURL_PRINT,

       STATUS,

       IS_SHOWINGRID,

       CLIENTTAG,

       IS_INITMISTABLE,

       FROMMAINPVIMATINSTANCEGUID)

      Select Row_ID,

             MATERIALINSTANCEGUID,

             MATERIALINSTANCENAME,

             ADDDATE,

             IS_DEFINED,

             ADDINWORKITEMGUID,

             ADDUSERGUID,

             PROCESSVERSIONINSTANCEGUID,

             MATERIALGUID,

             MATERIALNAME,

             SOURCE,

             TYPE,

             ATTACHSTORAGEINFOGROUPGUID,

             PAGEURL_READANDWRITE,

             PAGEURL_READ,

             PAGEURL_PRINT,

             STATUS,

             IS_SHOWINGRID,

             CLIENTTAG,

             IS_INITMISTABLE,

             FROMMAINPVIMATINSTANCEGUID

        From Workflow_PVI_Material

       where ProcessVersionInstanceGuid =

             T_ProcessVersionInstanceGuid;

    Delete from Workflow_PVI_Material

     where ProcessVersionInstanceGuid =

           T_ProcessVersionInstanceGuid;

  

    insert into Workflow_Transition_I_History

      (TRANSITIONINSTANCEGUID,

       TRANSITIONGUID,

       PROCESSVERSIONINSTANCEGUID,

       SOURCEACTIVIRYGUID,

       SOURCEACTIVIRYNAME,

       SRCACTINSTGUID,

       SRCACTINSTNAME,

       TARGETACTIVITYGUID,

       TARGETACTIVITYNAME,

       TGTACTINSTGUID,

       TGTACTINSTNAME,

       TYPE,

       TRANSITDATE,

       DIRECTION)

      Select TRANSITIONINSTANCEGUID,

             TRANSITIONGUID,

             PROCESSVERSIONINSTANCEGUID,

             SOURCEACTIVIRYGUID,

             SOURCEACTIVIRYNAME,

             SRCACTINSTGUID,

             SRCACTINSTNAME,

             TARGETACTIVITYGUID,

             TARGETACTIVITYNAME,

             TGTACTINSTGUID,

             TGTACTINSTNAME,

             TYPE,

             TRANSITDATE,

             DIRECTION

        From Workflow_Transition_Instance

       where ProcessVersionInstanceGuid =

             T_ProcessVersionInstanceGuid;

    Delete from Workflow_Transition_Instance

     where ProcessVersionInstanceGuid =

           T_ProcessVersionInstanceGuid;

  

    INSERT INTO Workflow_WorkItem_History

      (Row_ID,

       WorkItemGuid,

       ActivityGuid,

       ActivityName,

       ActivityInstanceGuid,

       WorkItemName,

       WorkItemType,

       WorkItemModeName,

       HandleURL,

       Status,

       Priority,

       SenderGuid,

       SenderName,

       Transactor,

       TransactorName,

       JobGuid,

       OperationGuid,

       ReadDate,

       OperationDate,

       OperatorGuid,

       OperatorName,

       Opinion,

       WaitHandleGuid,

       CreateDate,

       StartDate,

       EndDate,

       TerminateDate,

       StatusBeforeTerminate,

       LimitMinutes,

       ProcessGuid,

       ProcessVersionGuid,

       ProcessVersionName,

       ProcessVersionInstanceGuid,

       ProcessVersionInstanceName,

       GroupGuid,

       Is_Locked,

       LockerUserGuid,

       LockerDispName,

       LockDate,

       AgentForUserGuid,

       OperationType,

       LockerWindowGuid,

       ABAuditOpinion,

       TimeLimit,

       TimeLimitUnit,

       OverTimePoint,

       EarlyWarningPoint,

       Is_NeedSendEarlyWarning,

       Is_NeedSendOverTimeNotify,

       AgentForWorkItemGuid,

       OperatorForDisplayGuid,

       OperatorForDisplayName,

       Note,

       TRANSITIONINSTANCEGUID)

      Select Row_ID,

             WorkItemGuid,

             ActivityGuid,

             ActivityName,

             ActivityInstanceGuid,

             WorkItemName,

             WorkItemType,

             WorkItemModeName,

             HandleURL,

             Status,

             Priority,

             SenderGuid,

             SenderName,

             Transactor,

             TransactorName,

             JobGuid,

             OperationGuid,

             ReadDate,

             OperationDate,

             OperatorGuid,

             OperatorName,

             Opinion,

             WaitHandleGuid,

             CreateDate,

             StartDate,

             EndDate,

             TerminateDate,

             StatusBeforeTerminate,

             LimitMinutes,

             ProcessGuid,

             ProcessVersionGuid,

             ProcessVersionName,

             ProcessVersionInstanceGuid,

             ProcessVersionInstanceName,

             GroupGuid,

             Is_Locked,

             LockerUserGuid,

             LockerDispName,

             LockDate,

             AgentForUserGuid,

             OperationType,

             LockerWindowGuid,

             ABAuditOpinion,

             TimeLimit,

             TimeLimitUnit,

             OverTimePoint,

             EarlyWarningPoint,

             Is_NeedSendEarlyWarning,

             Is_NeedSendOverTimeNotify,

             AgentForWorkItemGuid,

             OperatorForDisplayGuid,

             OperatorForDisplayName,

             Note,

             TRANSITIONINSTANCEGUID

        From Workflow_WorkItem

       where ProcessVersionInstanceGuid =

             T_ProcessVersionInstanceGuid;

    Delete from Workflow_WorkItem

     where ProcessVersionInstanceGuid =

           T_ProcessVersionInstanceGuid;

  

    insert into Workflow_Pvi_Opinion_His

      (OPINIONGUID,

       WORKITEMGUID,

       ACTIVITYGUID,

       ACTIVITYNAME,

       ACTIVITYINSTANCEGUID,

       PVIGUID,

       OPINIONTEXT,

       ADDDATE,

       ADDUSERGUID,

       ADDUSERNAME)

      Select OPINIONGUID,

             WORKITEMGUID,

             ACTIVITYGUID,

             ACTIVITYNAME,

             ACTIVITYINSTANCEGUID,

             PVIGUID,

             OPINIONTEXT,

             ADDDATE,

             ADDUSERGUID,

             ADDUSERNAME

        From WORKFLOW_PVI_OPINION

       where PVIGUID = T_ProcessVersionInstanceGuid;

    Delete from WORKFLOW_PVI_OPINION

     where pviguid = T_ProcessVersionInstanceGuid;

  

    insert into Workflow_Context_Value_History

      (FIELDGUID,

       PROCESSVERSIONINSTANCEGUID,

       ACTIVITYINSTANCEGUID,

       FIELDNAME,

       FIELDTYPE,

       FIELDVALUE)

      Select FIELDGUID,

             PROCESSVERSIONINSTANCEGUID,

             ACTIVITYINSTANCEGUID,

             FIELDNAME,

             FIELDTYPE,

             FIELDVALUE

        From Workflow_Context_Value

       where PROCESSVERSIONINSTANCEGUID =

             T_ProcessVersionInstanceGuid;

    Delete from Workflow_Context_Value

     where ProcessVersionInstanceGuid =

           T_ProcessVersionInstanceGuid;

    update workflow_pvi

       set tag = '1'

     where ProcessVersionInstanceGuid =

           T_ProcessVersionInstanceGuid;

END

IF;



FETCH NEXT

FROM

	CURSOR_POINT INTO T_ProcessVersionInstanceGuid;



UNTIL Done

END

REPEAT

;





CLOSE CURSOR_POINT;



	 insert into Workflow_Activity_Instance_His

    (Row_ID,

     ActivityGuid,

     ActivityInstanceGuid,

     SUBPROCESSVERSIONINSTANCEGUID,

     Status,

     StartDate,

     ENDTIME,

     TERMINATEDATE,

     IS_OVERTIME,

     ROLLBACKTAG,

     ACTIVITYINSTANCENAME,

     ProcessVersionGuid,

     ProcessVersionInstanceGuid,

     Note)

    Select Row_ID,

           ActivityGuid,

           ActivityInstanceGuid,

           SUBPROCESSVERSIONINSTANCEGUID,

           Status,

           StartDate,

           ENDTIME,

           TERMINATEDATE,

           IS_OVERTIME,

           ROLLBACKTAG,

           ACTIVITYINSTANCENAME,

           ProcessVersionGuid,

           ProcessVersionInstanceGuid,

           Note

      From Workflow_Activity_Instance

     where ProcessVersionInstanceGuid = ProcessVersionInstanceGuid;

  Delete from Workflow_Activity_Instance

   where ProcessVersionInstanceGuid = ProcessVersionInstanceGuid;



   insert into Workflow_Pvi_Mistablerow_His

    (Row_ID,

     MATERIALINSTANCEGUID,

     TABLEID,

     SQL_TABLENAME,

     MISROWGUID,

     PVIGUID,

     MISTABLESETINSTANCEGUID)

    Select Row_ID,

           MATERIALINSTANCEGUID,

           TABLEID,

           SQL_TABLENAME,

           MISROWGUID,

           PVIGUID,

           MISTABLESETINSTANCEGUID

      From Workflow_Pvi_Mistablerow

     where PVIGUID = ProcessVersionInstanceGuid;

  Delete from Workflow_Pvi_Mistablerow

   where PVIGUID = ProcessVersionInstanceGuid;



  insert into Workflow_PVI_Material_His

    (Row_ID,

     MATERIALINSTANCEGUID,

     MATERIALINSTANCENAME,

     ADDDATE,

     IS_DEFINED,

     ADDINWORKITEMGUID,

     ADDUSERGUID,

     PROCESSVERSIONINSTANCEGUID,

     MATERIALGUID,

     MATERIALNAME,

     SOURCE,

     TYPE,

     ATTACHSTORAGEINFOGROUPGUID,

     PAGEURL_READANDWRITE,

     PAGEURL_READ,

     PAGEURL_PRINT,

     STATUS,

     IS_SHOWINGRID,

     CLIENTTAG,

     IS_INITMISTABLE,

     FROMMAINPVIMATINSTANCEGUID)

    Select Row_ID,

           MATERIALINSTANCEGUID,

           MATERIALINSTANCENAME,

           ADDDATE,

           IS_DEFINED,

           ADDINWORKITEMGUID,

           ADDUSERGUID,

           PROCESSVERSIONINSTANCEGUID,

           MATERIALGUID,

           MATERIALNAME,

           SOURCE,

           TYPE,

           ATTACHSTORAGEINFOGROUPGUID,

           PAGEURL_READANDWRITE,

           PAGEURL_READ,

           PAGEURL_PRINT,

           STATUS,

           IS_SHOWINGRID,

           CLIENTTAG,

           IS_INITMISTABLE,

           FROMMAINPVIMATINSTANCEGUID

      From Workflow_PVI_Material

     where ProcessVersionInstanceGuid = ProcessVersionInstanceGuid;

  Delete from Workflow_PVI_Material

   where ProcessVersionInstanceGuid = ProcessVersionInstanceGuid;



  insert into Workflow_Transition_I_History

    (TRANSITIONINSTANCEGUID,

     TRANSITIONGUID,

     PROCESSVERSIONINSTANCEGUID,

     SOURCEACTIVIRYGUID,

     SOURCEACTIVIRYNAME,

     SRCACTINSTGUID,

     SRCACTINSTNAME,

     TARGETACTIVITYGUID,

     TARGETACTIVITYNAME,

     TGTACTINSTGUID,

     TGTACTINSTNAME,

     TYPE,

     TRANSITDATE,

     DIRECTION)

    Select TRANSITIONINSTANCEGUID,

           TRANSITIONGUID,

           PROCESSVERSIONINSTANCEGUID,

           SOURCEACTIVIRYGUID,

           SOURCEACTIVIRYNAME,

           SRCACTINSTGUID,

           SRCACTINSTNAME,

           TARGETACTIVITYGUID,

           TARGETACTIVITYNAME,

           TGTACTINSTGUID,

           TGTACTINSTNAME,

           TYPE,

           TRANSITDATE,

           DIRECTION

      From Workflow_Transition_Instance

     where ProcessVersionInstanceGuid = ProcessVersionInstanceGuid;

  Delete from Workflow_Transition_Instance

   where ProcessVersionInstanceGuid = ProcessVersionInstanceGuid;



  INSERT INTO Workflow_WorkItem_History

    (Row_ID,

     WorkItemGuid,

     ActivityGuid,

     ActivityName,

     ActivityInstanceGuid,

     WorkItemName,

     WorkItemType,

     WorkItemModeName,

     HandleURL,

     Status,

     Priority,

     SenderGuid,

     SenderName,

     Transactor,

     TransactorName,

     JobGuid,

     OperationGuid,

     ReadDate,

     OperationDate,

     OperatorGuid,

     OperatorName,

     Opinion,

     WaitHandleGuid,

     CreateDate,

     StartDate,

     EndDate,

     TerminateDate,

     StatusBeforeTerminate,

     LimitMinutes,

     ProcessGuid,

     ProcessVersionGuid,

     ProcessVersionName,

     ProcessVersionInstanceGuid,

     ProcessVersionInstanceName,

     GroupGuid,

     Is_Locked,

     LockerUserGuid,

     LockerDispName,

     LockDate,

     AgentForUserGuid,

     OperationType,

     LockerWindowGuid,

     ABAuditOpinion,

     TimeLimit,

     TimeLimitUnit,

     OverTimePoint,

     EarlyWarningPoint,

     Is_NeedSendEarlyWarning,

     Is_NeedSendOverTimeNotify,

     AgentForWorkItemGuid,

     OperatorForDisplayGuid,

     OperatorForDisplayName,

     Note,

     TRANSITIONINSTANCEGUID)

    Select Row_ID,

           WorkItemGuid,

           ActivityGuid,

           ActivityName,

           ActivityInstanceGuid,

           WorkItemName,

           WorkItemType,

           WorkItemModeName,

           HandleURL,

           Status,

           Priority,

           SenderGuid,

           SenderName,

           Transactor,

           TransactorName,

           JobGuid,

           OperationGuid,

           ReadDate,

           OperationDate,

           OperatorGuid,

           OperatorName,

           Opinion,

           WaitHandleGuid,

           CreateDate,

           StartDate,

           EndDate,

           TerminateDate,

           StatusBeforeTerminate,

           LimitMinutes,

           ProcessGuid,

           ProcessVersionGuid,

           ProcessVersionName,

           ProcessVersionInstanceGuid,

           ProcessVersionInstanceName,

           GroupGuid,

           Is_Locked,

           LockerUserGuid,

           LockerDispName,

           LockDate,

           AgentForUserGuid,

           OperationType,

           LockerWindowGuid,

           ABAuditOpinion,

           TimeLimit,

           TimeLimitUnit,

           OverTimePoint,

           EarlyWarningPoint,

           Is_NeedSendEarlyWarning,

           Is_NeedSendOverTimeNotify,

           AgentForWorkItemGuid,

           OperatorForDisplayGuid,

           OperatorForDisplayName,

           Note,

           TRANSITIONINSTANCEGUID

      From Workflow_WorkItem

     where ProcessVersionInstanceGuid = ProcessVersionInstanceGuid;

  Delete from Workflow_WorkItem

   where ProcessVersionInstanceGuid = ProcessVersionInstanceGuid;



  insert into Workflow_Pvi_Opinion_His

    (OPINIONGUID,

     WORKITEMGUID,

     ACTIVITYGUID,

     ACTIVITYNAME,

     ACTIVITYINSTANCEGUID,

     PVIGUID,

     OPINIONTEXT,

     ADDDATE,

     ADDUSERGUID,

     ADDUSERNAME)

    Select OPINIONGUID,

           WORKITEMGUID,

           ACTIVITYGUID,

           ACTIVITYNAME,

           ACTIVITYINSTANCEGUID,

           PVIGUID,

           OPINIONTEXT,

           ADDDATE,

           ADDUSERGUID,

           ADDUSERNAME

      From WORKFLOW_PVI_OPINION

     where PVIGUID = ProcessVersionInstanceGuid;

  Delete from WORKFLOW_PVI_OPINION

   where pviguid = ProcessVersionInstanceGuid;



  insert into Workflow_Context_Value_History

    (FIELDGUID,

     PROCESSVERSIONINSTANCEGUID,

     ACTIVITYINSTANCEGUID,

     FIELDNAME,

     FIELDTYPE,

     FIELDVALUE)

    Select FIELDGUID,

           PROCESSVERSIONINSTANCEGUID,

           ACTIVITYINSTANCEGUID,

           FIELDNAME,

           FIELDTYPE,

           FIELDVALUE

      From Workflow_Context_Value

     where PROCESSVERSIONINSTANCEGUID = ProcessVersionInstanceGuid;

  Delete from Workflow_Context_Value

   where ProcessVersionInstanceGuid = ProcessVersionInstanceGuid;



COMMIT;

END;


create
    definer = root@localhost procedure DeleteProcessVersion(IN ProcessVersionGuid varchar(100)) sql security invoker
BEGIN

DECLARE TargetProcessVersionGuid varchar(100);

set	TargetProcessVersionGuid=ProcessVersionGuid;

Delete from Workflow_Activity where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_Activity_FieldAccess where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_Activity_LinkInfo where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_Activity_Material where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_Activity_Operation where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_Config where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_Context where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_Event where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_InvokeMethod where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_Method where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_Method_Parameter where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_Participator where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_PV_Material where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_PV_MisTableSet where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_PV_PrintAdapter where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_Transition where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_Transition_Condition where ProcessVersionGuid=TargetProcessVersionGuid;

Delete from Workflow_ProcessVersion where ProcessVersionGuid=TargetProcessVersionGuid;



END;


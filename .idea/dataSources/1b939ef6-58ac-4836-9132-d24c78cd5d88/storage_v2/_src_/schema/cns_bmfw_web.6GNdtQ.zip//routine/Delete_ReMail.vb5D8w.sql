create
    definer = root@localhost procedure Delete_ReMail() sql security invoker
BEGIN

	DECLARE Row_ID int;

	DECLARE MailGuid varchar(100);

	DECLARE mailGuid_cur CURSOR  for

  select Row_ID, MailGuid from DBMail_AllMails order by Row_id;

	

	open mailGuid_cur;

	

	REPEAT

    fetch mailGuid_cur

      into Row_ID, MailGuid;

    delete from DBMail_AllMails

     where MailGuid = MailGuid

       and Row_ID <> Row_ID;

	until done end repeat;

	close mailGuid_cur;

END;


create definer = root@localhost view view_cns_sms_info as
select `cns_bmfw_web`.`messages_center`.`MESSAGEITEMGUID`  AS `MESSAGEITEMGUID`,
       `cns_bmfw_web`.`messages_center`.`MESSAGETARGET`    AS `messagetarget`,
       `cns_bmfw_web`.`messages_center`.`CONTENT`          AS `content`,
       `cns_bmfw_web`.`messages_center`.`ISSEND`           AS `issend`,
       `cns_bmfw_web`.`messages_center`.`ISSCHEDULE`       AS `isschedule`,
       `cns_bmfw_web`.`messages_center`.`SCHEDULESENDDATE` AS `schedulesenddate`,
       `cns_bmfw_web`.`messages_center`.`GENERATEDATE`     AS `generatedate`,
       `cns_bmfw_web`.`messages_center`.`SENDMODE`         AS `sendmode`
from `cns_bmfw_web`.`messages_center`
where ((`cns_bmfw_web`.`messages_center`.`SENDMODE` = 1) or (`cns_bmfw_web`.`messages_center`.`SENDMODE` = 0))
union all
select `cns_bmfw_web`.`messages_center_histroy`.`MESSAGEITEMGUID`  AS `MESSAGEITEMGUID`,
       `cns_bmfw_web`.`messages_center_histroy`.`MESSAGETARGET`    AS `messagetarget`,
       `cns_bmfw_web`.`messages_center_histroy`.`CONTENT`          AS `content`,
       `cns_bmfw_web`.`messages_center_histroy`.`ISSEND`           AS `issend`,
       `cns_bmfw_web`.`messages_center_histroy`.`ISSCHEDULE`       AS `isschedule`,
       `cns_bmfw_web`.`messages_center_histroy`.`SCHEDULESENDDATE` AS `schedulesenddate`,
       `cns_bmfw_web`.`messages_center_histroy`.`GENERATEDATE`     AS `generatedate`,
       `cns_bmfw_web`.`messages_center_histroy`.`SENDMODE`         AS `sendmode`
from `cns_bmfw_web`.`messages_center_histroy`
where ((`cns_bmfw_web`.`messages_center_histroy`.`SENDMODE` = 1) or
       (`cns_bmfw_web`.`messages_center_histroy`.`SENDMODE` = 0));


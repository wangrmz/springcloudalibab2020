create
    definer = root@localhost procedure PAStat(IN UserGuids text, IN OuGuids text, IN WeekStartDate datetime,
                                              IN WeekEndDate datetime, IN MonthStartDate datetime,
                                              IN MonthEndDate datetime) sql security invoker
BEGIN

	DECLARE  vUserGuid   text;

  DECLARE vUserGuids  text;

  DECLARE vOuGuid     text;

  DECLARE vOuGuids    text;

  DECLARE splitIndex  int;

  DECLARE splitIndex1 int;

  DECLARE curIndex    int;



  set vUserGuids = UserGuids;

  set vOuGuids   = OuGuids;

  set splitIndex = instr(vUserGuids, ';');

  set splitIndex1 = instr(vOuGuids, ';');

  set curIndex   = 1;

	

	drop temporary table IF EXISTS temp_tb;

	create temporary table temp_tb 

	(SYSID int,

	DISPLAYNAME varchar(50),

	USERGUID varchar(50),

	OUGUID varchar(50),

	CATEGORYNUM varchar(50),

	CATEGORYNAME varchar(100),

	DTYPE int,

	MINCOUNT int,

	PUBCOUNT int

	);



  
  

  while splitIndex > 0 do

    set vUserGuid  = substr(vUserGuids, 1, splitIndex - 1);

    set vUserGuids = substr(vUserGuids, splitIndex + 1);

    set vOuGuid    = substr(vOuGuids, 1, splitIndex1 - 1);

    set vOuGuids   = substr(vOuGuids, splitIndex1 + 1);

  

    INSERT INTO Temp_tb

      (SysID, UserGuid, OUGuid, CategoryNum, DType, MinCount, PubCount)

      SELECT curIndex,

             vUserGuid,

             vOuGuid,

             CategoryNum,

             DType,

             MinCount,

             Getpainfocount(vUserGuid,

                            vOuGuid,

                            CategoryNum,

                            LimitType,

                            DType,

                            WeekStartDate,

                            WeekEndDate,

                            MonthStartDate,

                            MonthEndDate) PubCount

        FROM WebDB_PA_Count

       WHERE BelongTo = 'All'

          OR BelongTo = vUserGuid;

    set curIndex    = curIndex + 1;

    set splitIndex  = instr(vUserGuids, ';');

    set splitIndex1 = instr(vOuGuids, ';');

  end while;

  UPDATE temp_tb

     SET DisplayName =

         (SELECT DisplayName

            FROM FRame_User

           WHERE FRame_User.Userguid = Temp_tb.Userguid);

  UPDATE temp_tb

     SET CategoryName =

         (SELECT CategoryName

            FROM WebDB_Category

           WHERE WebDB_Category.Categorynum = Temp_tb.Categorynum);

	select * from temp_tb;

END;


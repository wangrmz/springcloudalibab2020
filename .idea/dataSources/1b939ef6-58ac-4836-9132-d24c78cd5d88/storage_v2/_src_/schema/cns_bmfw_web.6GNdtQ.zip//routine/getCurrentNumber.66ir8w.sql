create
    definer = root@localhost procedure getCurrentNumber(IN nname varchar(100), IN nflag varchar(100), IN fnlen int,
                                                        OUT cnumber varchar(100))
begin DECLARE   mvalue  int;  select  max(cast(CurrentValue  as  SIGNED))  into  mvalue    from  code_maxnumber  where  NumberName  =  nname  and  NumberFlag  =  nflag;  if mvalue  is  null  then  insert  into  code_maxnumber(NumberName,  NumberFlag,  Currentvalue)  values(nname,  nflag,  1); else update  code_maxnumber  set  currentvalue  =  currentvalue  +  1  where  NumberName= nname  and  NumberFlag  =  nflag; end  if;   if(  ifnull(mvalue,0)  =  0)  then set  cnumber = concat(nflag,lpad('0',  fnlen - 1,  '0'),'1'); else set   mvalue=mvalue+1; set   cnumber = concat(nflag,lpad('0',fnlen - length(cast(mvalue  as  CHAR)),  '0'),cast(mvalue  as  CHAR)); end  if;  END;


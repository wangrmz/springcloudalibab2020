create definer = root@localhost view view_webinfo_nocontrol as
select `cns_bmfw_web`.`webinfo_infomation`.`InfoGuid`              AS `InfoGuid`,
       `cns_bmfw_web`.`webinfo_infomation`.`Row_ID`                AS `Row_ID`,
       `cns_bmfw_web`.`webinfo_infomation`.`InfoType`              AS `InfoType`,
       `cns_bmfw_web`.`webinfo_infomation`.`InfoStartDate`         AS `InfoStartDate`,
       `cns_bmfw_web`.`webinfo_infomation`.`InfoEndDate`           AS `InfoEndDate`,
       `cns_bmfw_web`.`webinfo_infomation`.`Title`                 AS `Title`,
       `cns_bmfw_web`.`webinfo_infomation`.`Content`               AS `Content`,
       `cns_bmfw_web`.`webinfo_infomation`.`Author`                AS `Author`,
       `cns_bmfw_web`.`webinfo_infomation`.`Reprint`               AS `Reprint`,
       `cns_bmfw_web`.`webinfo_infomation`.`Printable`             AS `Printable`,
       `cns_bmfw_web`.`webinfo_infomation`.`Commentable`           AS `Commentable`,
       `cns_bmfw_web`.`webinfo_infomation`.`InfoDate`              AS `InfoDate`,
       `cns_bmfw_web`.`webinfo_infomation`.`AddUserGuid`           AS `AddUserGuid`,
       `cns_bmfw_web`.`webinfo_infomation`.`PubTime`               AS `PubTime`,
       `cns_bmfw_web`.`webinfo_infomation`.`PubObjType`            AS `PubObjType`,
       `cns_bmfw_web`.`webinfo_infomation`.`PubObjName`            AS `PubObjName`,
       `cns_bmfw_web`.`webinfo_infomation`.`ReadLimit`             AS `ReadLimit`,
       `cns_bmfw_web`.`webinfo_infomation`.`OrderNumber`           AS `OrderNumber`,
       `cns_bmfw_web`.`webinfo_infomation`.`IsTop`                 AS `IsTop`,
       `cns_bmfw_web`.`webinfo_infomation_category`.`CategoryGuid` AS `CategoryGuid`,
       `cns_bmfw_web`.`webinfo_infomation_category`.`CategoryName` AS `CategoryName`,
       `cns_bmfw_web`.`webinfo_infomation`.`Status`                AS `Status`,
       `cns_bmfw_web`.`webinfo_infomation`.`Clicktimes`            AS `clicktimes`,
       `cns_bmfw_web`.`webinfo_infomation`.`FeedBackNum`           AS `feedbacknum`,
       `cns_bmfw_web`.`webinfo_infomation`.`LastFBTime`            AS `lastfbtime`
from (`cns_bmfw_web`.`webinfo_infomation` join `cns_bmfw_web`.`webinfo_infomation_category`
      on ((`cns_bmfw_web`.`webinfo_infomation`.`InfoGuid` = `cns_bmfw_web`.`webinfo_infomation_category`.`InfoGuid`)));


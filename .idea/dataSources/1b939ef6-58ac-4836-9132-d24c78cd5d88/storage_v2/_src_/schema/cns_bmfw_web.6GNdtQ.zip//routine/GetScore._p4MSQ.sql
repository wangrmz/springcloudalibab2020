create
    definer = root@localhost function GetScore(InfoId varchar(100)) returns int sql security invoker
BEGIN

	DECLARE returnValue int;

	SELECT max(score) into returnValue FROM View_InfoMain WHERE InfoID=InfoID ;

	if(returnValue is NULL) then

      set returnValue = 0;

      end if;

return returnValue;

END;


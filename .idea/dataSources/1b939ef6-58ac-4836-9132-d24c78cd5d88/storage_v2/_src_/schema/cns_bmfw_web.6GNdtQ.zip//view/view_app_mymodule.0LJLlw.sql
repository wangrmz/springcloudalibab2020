create definer = root@localhost view view_app_mymodule as
select `pm`.`rowguid`        AS `rowguid`,
       `pm`.`moduleguid`     AS `moduleguid`,
       `pm`.`belongdeskguid` AS `mydeskguid`,
       `pm`.`belonguserguid` AS `belonguserguid`,
       `pm`.`ordernumber`    AS `ordernumber`,
       `pm`.`isdisable`      AS `isdisable`,
       `pm`.`uiguid`         AS `uiguid`,
       `m`.`appguid`         AS `appguid`,
       `m`.`Icon`            AS `Icon`,
       `m`.`IconContent`     AS `IconContent`,
       `m`.`iconContentType` AS `IconContentType`,
       `m`.`iconupdatetime`  AS `iconupdatetime`,
       `m`.`modulename`      AS `modulename`,
       `m`.`modulemenuname`  AS `modulemenuname`,
       `m`.`moduleurl`       AS `moduleurl`,
       `m`.`isblank`         AS `isblank`,
       `m`.`MessageCountUrl` AS `MessageCountUrl`
from (`cns_bmfw_web`.`app_personalmodule` `pm` join `cns_bmfw_web`.`app_module` `m`
      on ((`pm`.`moduleguid` = convert(`m`.`moduleguid` using utf8mb4))))
where (`m`.`isdisable` = 0);


create
    definer = root@localhost procedure ClearDirtyData() sql security invoker
BEGIN

	Delete from Workflow_ProcessVersion where ProcessGuid not in(select ProcessGuid from Workflow_Process);

Delete from Workflow_PV_Material where ProcessVersionGuid not in(select ProcessVersionGuid from Workflow_ProcessVersion);

Delete from Workflow_PV_MisTableSet where MaterialGuid not in(select MaterialGuid from Workflow_PV_Material);

Delete from Workflow_PV_PrintAdapter where ProcessVersionGuid not in(select ProcessVersionGuid from Workflow_ProcessVersion);

Delete from Workflow_Context where ProcessVersionGuid not in(select ProcessVersionGuid from Workflow_ProcessVersion);

Delete from Workflow_Activity where ProcessVersionGuid not in(select ProcessVersionGuid from Workflow_ProcessVersion);

Delete from Workflow_Activity_Material where  ( ActivityGuid not in(select ActivityGuid from Workflow_ProcessVersion) or MaterialGuid not in(select MaterialGuid from Workflow_PV_Material) );

Delete from Workflow_Activity_FieldAccess where ActivityMaterialGuid not in(select ActivityMaterialGuid from Workflow_Activity_Material);

Delete from Workflow_Activity_Operation where ActivityGuid not in(select ActivityGuid from Workflow_Activity);

delete from  Workflow_Event where  ( eventtype=10 or  eventtype=15 or eventtype=20 or eventtype=25 ) and SourceGuid not in (select ActivityGuid from Workflow_Activity) ;

delete from  Workflow_Event where  ( eventtype=50 or  eventtype=55  ) and SourceGuid not in (select OperationGuid from Workflow_Activity_Operation) ;

delete  from  Workflow_Config where BelongTo=22  and SourceGuid not   in (select OperationGuid from Workflow_Activity_Operation) ;

delete from Workflow_Config where BelongTo=10  and SourceGuid not   in (select ProcessVersionGuid from Workflow_ProcessVersion ) ;

delete from  Workflow_Config where BelongTo=20  and SourceGuid not   in (select ActivityGuid from  Workflow_Activity ) ;

delete  from  Workflow_Config where BelongTo=30  and SourceGuid not   in (select TransitionGuid from  Workflow_Transition ) ;

delete  from  Workflow_Config where BelongTo=40  and SourceGuid not   in (select MaterialGuid from    Workflow_PV_Material) ;



delete from Workflow_Participator where sourceGuid = '' or  sourceGuid is null ;

delete from Workflow_Participator where ProcessVersionGuid  not in (select ProcessVersionGuid from Workflow_ProcessVersion);



delete from Workflow_Participator where

 (belongto=30 or belongto=35  )

and  sourceguid not in (select TransitionGuid from Workflow_Transition);



delete from Workflow_Participator where

  (belongto=10 or belongto=15 or belongto=20 )

and  sourceguid not in (select ActivityGuid from Workflow_Activity);



UPDATE Workflow_Participator SET Workflow_Participator.ProcessVersionGuid =

(SELECT Workflow_Activity.ProcessVersionGuid FROM Workflow_Activity WHERE

Workflow_Activity.ActivityGuid = Workflow_Participator.SourceGuid

)

WHERE Workflow_Participator.ProcessVersionGuid is null and (Workflow_Participator.belongto=10 or Workflow_Participator.belongto=15 or Workflow_Participator.belongto=20);





UPDATE Workflow_Participator SET Workflow_Participator.ProcessVersionGuid =

(SELECT Workflow_Transition.ProcessVersionGuid FROM Workflow_Transition WHERE

Workflow_Transition.TransitionGuid = Workflow_Participator.SourceGuid

)

WHERE Workflow_Participator.ProcessVersionGuid is null and (Workflow_Participator.belongto=30 or Workflow_Participator.belongto=35);



END;


create
    definer = root@localhost procedure cms_generate_dbuser(IN p_dbUser varchar(50), IN p_ipAndPort varchar(100),
                                                           IN p_dsGuid varchar(50), IN p_dbtype varchar(50),
                                                           IN p_loginid varchar(50), IN p_dbpassword varchar(50))
    sql security invoker
begin

  DECLARE dscount int;

  DECLARE sqllimit varchar(500);

  set dscount = 0;

	set sqllimit= CONCAT('create database ', p_dbUser);

  set @sql = sqllimit;  

  PREPARE stmt FROM @sql;  

  EXECUTE stmt;  

  set sqllimit=concat('grant SELECT,INSERT,UPDATE,DELETE,CREATE,DROP,ALTER on ',p_dbUser,'.* TO ',p_loginid,'@localhost IDENTIFIED BY \'11111\'');

  set @sql = sqllimit;  

  PREPARE stmt FROM @sql;  

  EXECUTE stmt;  

  DEALLOCATE PREPARE stmt;

  select count(*)

    into dscount

    from datasource

   where dsname = concat('子站_' , p_dbUser);

  if (dscount = 0) then

    insert into datasource

      (dsid,

       dstype,

       dsname,

       loginuser,

       loginpwd,

       servername,

       dbname,

       CONNECTIONSTRING

      )

    values

      (

       p_dsGuid,

       p_dbtype,

       concat('子站_' , p_dbUser),

       p_loginid,

       p_dbpassword,

       p_ipAndPort,

       p_dbUser,

			 concat('server=',p_ipAndPort,';User ID=',p_loginid,';Password=',p_dbpassword,';Database=',p_dbUser)

      );

  end if;

END;


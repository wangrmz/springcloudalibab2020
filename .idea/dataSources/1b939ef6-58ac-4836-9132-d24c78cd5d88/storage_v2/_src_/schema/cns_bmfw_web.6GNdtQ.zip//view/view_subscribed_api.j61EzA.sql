create definer = root@localhost view view_subscribed_api as
select `b`.`apiguid`     AS `apiguid`,
       `b`.`categoryid`  AS `categoryid`,
       `b`.`status`      AS `status`,
       `b`.`description` AS `description`,
       `b`.`apiname`     AS `apiname`,
       `a`.`isenable`    AS `isenable`,
       `a`.`refuse`      AS `refuse`,
       `a`.`appguid`     AS `appguid`,
       `a`.`rowguid`     AS `rowguid`
from (`cns_bmfw_web`.`api_subscribe` `a` join `cns_bmfw_web`.`api_info` `b`
      on ((`a`.`apiguid` = convert(`b`.`RowGuid` using utf8mb4))));


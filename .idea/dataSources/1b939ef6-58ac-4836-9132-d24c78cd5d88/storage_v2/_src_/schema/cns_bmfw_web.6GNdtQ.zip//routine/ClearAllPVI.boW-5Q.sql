create
    definer = root@localhost procedure ClearAllPVI() sql security invoker
BEGIN

	delete  from WorkFlow_AttachStorage where AttachGuid not in

(select AttachStorageGuid from Workflow_AttachStorageInfo where AttachStorageInfoGroupGuid in

        (select Template_ASInfoGroupGuid from Workflow_PV_Material )

);





delete from Workflow_AttachStorageInfo where AttachStorageInfoGroupGuid not in

(select Template_ASInfoGroupGuid from Workflow_PV_Material );





Delete from Workflow_Activity_Instance ;

Delete from Workflow_PVI_Material ;

Delete from Workflow_PVI_MisTableRow ;

Delete from Workflow_Transition_Instance ;

Delete from Messages_Center where MessageItemGuid in ( select WorkItemGuid from Workflow_WorkItem);

Delete from Messages_Center_Histroy where MessageItemGuid in ( select WorkItemGuid from Workflow_WorkItem);

Delete from Workflow_WorkItem ;

Delete from Workflow_WorkItem_Notify ;

Delete from Workflow_PVI ;

END;


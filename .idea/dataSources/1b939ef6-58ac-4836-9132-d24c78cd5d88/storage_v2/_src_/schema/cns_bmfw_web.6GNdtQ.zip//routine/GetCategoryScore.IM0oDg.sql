create
    definer = root@localhost function GetCategoryScore(UserGuid varchar(100), FromDate date, ToDate date) returns int
    sql security invoker
BEGIN

	DECLARE returnValue int;

	SELECT Sum(GetScore(InfoID)) into returnValue FROM WebDB_Information WHERE UserGuid=UserGuid AND PubInWebDate BETWEEN FromDate AND ToDate;

if(returnValue is NULL) then

      set returnValue = 0;

      end if;

return returnValue;

END;


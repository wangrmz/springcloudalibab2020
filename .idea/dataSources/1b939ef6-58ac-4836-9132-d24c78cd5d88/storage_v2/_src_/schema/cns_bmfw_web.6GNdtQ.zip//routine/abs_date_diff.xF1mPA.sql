create
    definer = root@localhost procedure abs_date_diff(IN p_date1 datetime, IN p_date2 datetime, OUT p_years int,
                                                     OUT p_months int, OUT p_days int) sql security invoker
BEGIN

	DECLARE l_months int;

	DECLARE l_date datetime;

	

	set l_months = TIMESTAMPDIFF(month,p_date1,p_date2);

	set p_years = floor(abs(l_months)/12);

	set p_days = (abs(l_months) - floor(abs(l_months)))*31;

	set p_months = floor(abs(l_months) - (12 * p_years));



END;


create
    definer = root@localhost procedure update_col()
begin if not exists (select null from information_schema.columns where table_schema = database() and table_name = 'cns_kinfo_reqtemplate' and column_name='AREACODE') then alter table cns_kinfo_reqtemplate add AREACODE varchar(50) NULL; end if; end;


create definer = root@localhost view view_convert_detail as
select `cns_bmfw_web`.`oa_converter_relation`.`RowGuid`    AS `RowGuid`,
       `cns_bmfw_web`.`oa_converter_relation`.`ToMark`     AS `ToMark`,
       `cns_bmfw_web`.`oa_converter_relation`.`FromMark`   AS `FromMark`,
       `cns_bmfw_web`.`oa_converter_relation`.`Fromguid`   AS `Fromguid`,
       `cns_bmfw_web`.`oa_converter_relation`.`Toguid`     AS `Toguid`,
       `cns_bmfw_web`.`oa_converter_relation`.`Baseouguid` AS `Baseouguid`,
       `cns_bmfw_web`.`oa_converter_relation`.`fromname`   AS `fromname`,
       `cns_bmfw_web`.`oa_converter_relation`.`toname`     AS `toname`,
       `cns_bmfw_web`.`oa_converter_params`.`serverurl`    AS `serverurl`,
       `cns_bmfw_web`.`oa_converter_params`.`addpageurl`   AS `addpageurl`,
       `cns_bmfw_web`.`oa_converter_params`.`viewpageurl`  AS `viewpageurl`,
       `cns_bmfw_web`.`oa_converter_params`.`Inuse`        AS `Inuse`
from (`cns_bmfw_web`.`oa_converter_relation` join `cns_bmfw_web`.`oa_converter_params`
      on ((`cns_bmfw_web`.`oa_converter_relation`.`Toguid` = `cns_bmfw_web`.`oa_converter_params`.`RowGuid`)));


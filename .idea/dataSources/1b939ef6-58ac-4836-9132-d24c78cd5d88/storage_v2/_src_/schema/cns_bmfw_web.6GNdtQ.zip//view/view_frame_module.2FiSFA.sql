create definer = root@localhost view view_frame_module as
select `cns_bmfw_web`.`frame_moduleright`.`ROW_ID`      AS `Row_ID`,
       `cns_bmfw_web`.`frame_moduleright`.`MODULEGUID`  AS `ModuleGuid`,
       `cns_bmfw_web`.`frame_moduleright`.`ALLOWTO`     AS `AllowTo`,
       `cns_bmfw_web`.`frame_moduleright`.`ALLOWTYPE`   AS `AllowType`,
       `cns_bmfw_web`.`frame_module`.`MODULECODE`       AS `ModuleCode`,
       `cns_bmfw_web`.`frame_module`.`MODULENAME`       AS `ModuleName`,
       `cns_bmfw_web`.`frame_module`.`MODULEURL`        AS `ModuleUrl`,
       `cns_bmfw_web`.`frame_module`.`MOUDLEMENUNAME`   AS `MoudleMenuName`,
       `cns_bmfw_web`.`frame_module`.`ORDERNUMBER`      AS `OrderNumber`,
       `cns_bmfw_web`.`frame_module`.`ISDISABLE`        AS `isDisable`,
       `cns_bmfw_web`.`frame_module`.`ISBLANK`          AS `isBlank`,
       `cns_bmfw_web`.`frame_module`.`BIGICONADDRESS`   AS `bigIconAddress`,
       `cns_bmfw_web`.`frame_module`.`SMALLICONADDRESS` AS `SmallIconAddress`,
       `cns_bmfw_web`.`frame_module`.`MODULETYPE`       AS `ModuleType`,
       `cns_bmfw_web`.`frame_module`.`ISADDOU`          AS `IsAddOu`
from (`cns_bmfw_web`.`frame_moduleright` join `cns_bmfw_web`.`frame_module`
      on ((`cns_bmfw_web`.`frame_moduleright`.`MODULEGUID` = `cns_bmfw_web`.`frame_module`.`MODULEGUID`)))
where (`cns_bmfw_web`.`frame_module`.`MODULECODE` is not null);


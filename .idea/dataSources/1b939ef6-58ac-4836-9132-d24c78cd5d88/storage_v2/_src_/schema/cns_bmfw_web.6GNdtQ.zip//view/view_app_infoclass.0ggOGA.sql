create definer = root@localhost view view_app_infoclass as
select `a`.`RowGuid`      AS `rowguid`,
       `a`.`APPNAME`      AS `appname`,
       `b`.`appclassguid` AS `appclassguid`,
       `b`.`appclassname` AS `appclassname`,
       `a`.`ORDERNUM`     AS `ordernum`,
       `b`.`ordernumber`  AS `ordernumber`
from (`cns_bmfw_web`.`app_info` `a` left join `cns_bmfw_web`.`app_class` `b`
      on ((`a`.`APPCLASS` = `b`.`appclassguid`)));


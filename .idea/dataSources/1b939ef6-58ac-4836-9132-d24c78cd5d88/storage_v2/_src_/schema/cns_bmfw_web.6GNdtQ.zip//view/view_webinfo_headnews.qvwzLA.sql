create definer = root@localhost view view_webinfo_headnews as
select `cns_bmfw_web`.`webinfo_category`.`CategoryGuid`    AS `CategoryGuid`,
       `cns_bmfw_web`.`webinfo_headnews`.`HEADNEWSGUID`    AS `HEADNEWSGUID`,
       `cns_bmfw_web`.`webinfo_headnews`.`ATTACHGUID`      AS `attachguid`,
       `cns_bmfw_web`.`webinfo_infomation`.`PubTime`       AS `PubTime`,
       `cns_bmfw_web`.`webinfo_headnews`.`ORDERNUM`        AS `ORDERNUM`,
       `cns_bmfw_web`.`webinfo_headnews`.`ISPUBLISH`       AS `ISPUBLISH`,
       `cns_bmfw_web`.`webinfo_headnews`.`BASEOUGUID`      AS `BASEOUGUID`,
       `cns_bmfw_web`.`webinfo_headnews`.`webpicurl`       AS `webpicurl`,
       `cns_bmfw_web`.`webinfo_infomation`.`InfoGuid`      AS `infoguid`,
       `cns_bmfw_web`.`webinfo_infomation`.`Title`         AS `title`,
       `cns_bmfw_web`.`webinfo_infomation`.`InfoDate`      AS `InfoDate`,
       `cns_bmfw_web`.`webinfo_infomation`.`ReadLimit`     AS `ReadLimit`,
       `cns_bmfw_web`.`webinfo_infomation`.`InfoStartDate` AS `InfoStartDate`,
       `cns_bmfw_web`.`webinfo_infomation`.`InfoEndDate`   AS `InfoEndDate`,
       `cns_bmfw_web`.`webinfo_infomation`.`IsTop`         AS `IsTop`,
       `cns_bmfw_web`.`webinfo_infomation`.`OrderNumber`   AS `CategoryOrderNumber`,
       `cns_bmfw_web`.`webinfo_infomation`.`Status`        AS `Status`
from ((`cns_bmfw_web`.`webinfo_headnews` join `cns_bmfw_web`.`webinfo_infomation`
       on ((`cns_bmfw_web`.`webinfo_headnews`.`INFOGUID` =
            `cns_bmfw_web`.`webinfo_infomation`.`InfoGuid`))) left join `cns_bmfw_web`.`webinfo_category`
      on ((`cns_bmfw_web`.`webinfo_infomation`.`CategoryGuid` = `cns_bmfw_web`.`webinfo_category`.`CategoryGuid`)));


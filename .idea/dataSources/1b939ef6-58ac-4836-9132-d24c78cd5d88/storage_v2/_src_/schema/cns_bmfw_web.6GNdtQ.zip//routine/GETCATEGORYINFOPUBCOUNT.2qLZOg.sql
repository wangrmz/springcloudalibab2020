create
    definer = root@localhost function GETCATEGORYINFOPUBCOUNT(parCategoryNum varchar(100), InfoStatusCode int,
                                                              parStartDate datetime, parEndDate datetime) returns int
    sql security invoker
BEGIN 

	DECLARE returnValue int;

	set returnValue = 0;



	select count(InfoID)

    into returnValue

    from View_InfoMain

   where substr(CategoryNum, 1, char_length(CategoryNum)) = parCategoryNum

     and InfoStatusCode = InfoStatusCode

     AND PubInWebDate BETWEEN parStartDate AND parEndDate;

  return returnValue;

END;


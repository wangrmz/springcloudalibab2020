create
    definer = root@localhost procedure epoint_framemodule_insert()
begin if not exists (select 1 from  frame_module where moduleguid = 'e87a7be4-51b1-4225-be44-d382882f3b67') then insert into Frame_Module(ModuleGuid,ModuleCode,ModuleName,MoudleMenuName,ModuleUrl,OrderNumber,isDisable,isBlank,bigIconAddress,SmallIconAddress,ModuleType,IsAddOu) values ('e87a7be4-51b1-4225-be44-d382882f3b67','9999011000140008','提示音管理','提示音管理','framemanager/orga/uiset/sounds/soundslist',0,0,0,';','','public',0); insert into frame_moduleright (MODULEGUID, ALLOWTO, ALLOWTYPE, isfromsoa, righttype, modulerightmode) VALUES ('e87a7be4-51b1-4225-be44-d382882f3b67', '1eb07a29-51c8-4944-8dc7-594a8fddf681', 'Role', NULL, 'public', NULL); end if; end;


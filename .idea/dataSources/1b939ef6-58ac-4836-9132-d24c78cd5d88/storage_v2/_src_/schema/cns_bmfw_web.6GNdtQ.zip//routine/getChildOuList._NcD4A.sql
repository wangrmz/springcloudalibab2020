create
    definer = root@localhost function getChildOuList(rootId varchar(50)) returns longtext
BEGIN

	DECLARE sTemp longtext;

	DECLARE sTempChd longtext;

	SET@@group_concat_max_len = 102400;

	SET sTemp = '$';

	SET sTempChd = rootId;

WHILE sTempChd IS NOT NULL DO

	SET sTemp = concat(sTemp, ',', sTempChd);

	SELECT group_concat(ouguid) INTO sTempChd FROM frame_ou

	WHERE FIND_IN_SET(parentouguid, sTempChd) > 0;

END

WHILE;

	SET@@group_concat_max_len = 1024;

RETURN SUBSTRING(sTemp, 3);

END;


create definer = root@localhost view view_cns_jxkh_rule_item as
select `a`.`RowGuid`      AS `RowGuid`,
       `a`.`RULEGUID`     AS `RULEGUID`,
       `a`.`ITEMSERIAL`   AS `ITEMSERIAL`,
       `a`.`ITEMNAME`     AS `ITEMNAME`,
       `a`.`CALTYPE`      AS `CALTYPE`,
       `a`.`ADDSUBTYPE`   AS `ADDSUBTYPE`,
       `a`.`SCORENUM`     AS `SCORENUM`,
       `a`.`REGTYPE`      AS `REGTYPE`,
       `a`.`RULERANGE`    AS `RULERANGE`,
       `a`.`ISHASCON`     AS `ISHASCON`,
       `a`.`ORDERNUMBER`  AS `ORDERNUMBER`,
       `a`.`NOTE`         AS `NOTE`,
       `b`.`DEFAULTSCORE` AS `DEFAULTSCORE`,
       `b`.`RULESCORE`    AS `RULESCORE`,
       `b`.`RULESERIAL`   AS `RULESERIAL`,
       `a`.`AREACODE`     AS `AREACODE`
from (`cns_bmfw_web`.`cns_jxkh_ruleitem` `a` join `cns_bmfw_web`.`cns_jxkh_rulescore` `b`
      on ((`a`.`RULEGUID` = `b`.`RowGuid`)))
where (`b`.`ISUSED` = 1);


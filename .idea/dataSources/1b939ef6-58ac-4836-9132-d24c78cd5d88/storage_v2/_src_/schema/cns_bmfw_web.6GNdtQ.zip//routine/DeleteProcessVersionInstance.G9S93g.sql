create
    definer = root@localhost procedure DeleteProcessVersionInstance(IN c_pviguid varchar(50))
BEGIN

	DECLARE

		T_ProcessVersionInstanceGuid VARCHAR (50);



DECLARE

	done INT DEFAULT 0;





DECLARE

	CURSOR_POINT CURSOR FOR SELECT

		PROCESSVERSIONINSTANCEGUID

	FROM

		workflow_pvi

	WHERE

		MAINPVIGUID = c_pviguid;







DECLARE

	CONTINUE HANDLER FOR SQLSTATE '02000'

SET done = 1;





OPEN CURSOR_POINT;





FETCH NEXT

FROM

	CURSOR_POINT INTO T_ProcessVersionInstanceGuid;





REPEAT



IF NOT Done THEN

	DELETE

FROM

	WorkFlow_AttachStorage

WHERE

	AttachGuid IN (

		SELECT

			AttachStorageGuid

		FROM

			Workflow_AttachStorageInfo

		WHERE

			AttachStorageInfoGroupGuid IN (

				SELECT

					AttachStorageInfoGroupGuid

				FROM

					Workflow_PVI_Material

				WHERE

					ProcessVersionInstanceGuid = T_ProcessVersionInstanceGuid

			)

	);



DELETE

FROM

	Workflow_AttachStorageInfo

WHERE

	PVIGuid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	Frame_AttachInfo

WHERE

	CliengGuid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	Frame_AttachStorage

WHERE

	CliengGuid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	Workflow_Activity_Instance

WHERE

	ProcessVersionInstanceGuid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	Workflow_Activity_Instance_His

WHERE

	ProcessVersionInstanceGuid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	Workflow_PVI_Material

WHERE

	ProcessVersionInstanceGuid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	Workflow_Pvi_Material_His

WHERE

	ProcessVersionInstanceGuid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	Workflow_PVI_MisTableRow

WHERE

	PVIGuid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	Workflow_Pvi_Mistablerow_His

WHERE

	PVIGuid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	Workflow_Transition_Instance

WHERE

	ProcessVersionInstanceGuid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	Workflow_Transition_I_History

WHERE

	ProcessVersionInstanceGuid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	Workflow_WorkItem

WHERE

	ProcessVersionInstanceGuid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	Workflow_WorkItem_History

WHERE

	ProcessVersionInstanceGuid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	WORKFLOW_PVI_OPINION

WHERE

	pviguid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	WORKFLOW_PVI_OPINION_HIS

WHERE

	pviguid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	Workflow_Def

WHERE

	pviguid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	Workflow_PVI

WHERE

	ProcessVersionInstanceGuid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	Workflow_Context_Value

WHERE

	ProcessVersionInstanceGuid = T_ProcessVersionInstanceGuid;



DELETE

FROM

	Workflow_Context_Value_History

WHERE

	ProcessVersionInstanceGuid = T_ProcessVersionInstanceGuid;





END

IF;



FETCH NEXT

FROM

	CURSOR_POINT INTO T_ProcessVersionInstanceGuid;



UNTIL Done

END

REPEAT

;





CLOSE CURSOR_POINT;



DELETE

FROM

	WorkFlow_AttachStorage

WHERE

	AttachGuid IN (

		SELECT

			AttachStorageGuid

		FROM

			Workflow_AttachStorageInfo

		WHERE

			AttachStorageInfoGroupGuid IN (

				SELECT

					AttachStorageInfoGroupGuid

				FROM

					Workflow_PVI_Material

				WHERE

					ProcessVersionInstanceGuid = c_pviguid

			)

	);



DELETE

FROM

	Workflow_AttachStorageInfo

WHERE

	PVIGuid = c_pviguid;



DELETE

FROM

	Frame_AttachInfo

WHERE

	CliengGuid = c_pviguid;



DELETE

FROM

	Frame_AttachStorage

WHERE

	CliengGuid = c_pviguid;



DELETE

FROM

	Workflow_Activity_Instance

WHERE

	ProcessVersionInstanceGuid = c_pviguid;



DELETE

FROM

	Workflow_Activity_Instance_His

WHERE

	ProcessVersionInstanceGuid = c_pviguid;



DELETE

FROM

	Workflow_PVI_Material

WHERE

	ProcessVersionInstanceGuid = c_pviguid;



DELETE

FROM

	Workflow_Pvi_Material_His

WHERE

	ProcessVersionInstanceGuid = c_pviguid;



DELETE

FROM

	Workflow_PVI_MisTableRow

WHERE

	PVIGuid = c_pviguid;



DELETE

FROM

	Workflow_Pvi_Mistablerow_His

WHERE

	PVIGuid = c_pviguid;



DELETE

FROM

	Workflow_Transition_Instance

WHERE

	ProcessVersionInstanceGuid = c_pviguid;



DELETE

FROM

	Workflow_Transition_I_History

WHERE

	ProcessVersionInstanceGuid = c_pviguid;



DELETE

FROM

	Workflow_WorkItem

WHERE

	ProcessVersionInstanceGuid = c_pviguid;



DELETE

FROM

	Workflow_WorkItem_History

WHERE

	ProcessVersionInstanceGuid = c_pviguid;



DELETE

FROM

	WORKFLOW_PVI_OPINION

WHERE

	pviguid = c_pviguid;



DELETE

FROM

	WORKFLOW_PVI_OPINION_HIS

WHERE

	pviguid = c_pviguid;



DELETE

FROM

	Workflow_Def

WHERE

	pviguid = c_pviguid;



DELETE

FROM

	Workflow_PVI

WHERE

	ProcessVersionInstanceGuid = c_pviguid;



DELETE

FROM

	Workflow_Context_Value

WHERE

	ProcessVersionInstanceGuid = c_pviguid;



DELETE

FROM

	Workflow_Context_Value_History

WHERE

	ProcessVersionInstanceGuid = c_pviguid;



DELETE

FROM

	messages_center

WHERE

	PVIGUID = c_pviguid;



DELETE

FROM

	messages_center_histroy

WHERE

	PVIGUID = c_pviguid;



COMMIT;





END;


create
    definer = root@localhost function GetExtraScore(UserGuid varchar(100), FromDate date, ToDate date) returns int
    sql security invoker
BEGIN

	DECLARE returnValue int;

	SELECT Sum(Score) INTO returnValue FROM WebDB_PA_Score WHERE UserGuid=UserGuid AND PostDate BETWEEN FromDate AND ToDate;

if(returnValue is NULL) then

      set returnValue = 0;

      end if;

return returnValue;

END;


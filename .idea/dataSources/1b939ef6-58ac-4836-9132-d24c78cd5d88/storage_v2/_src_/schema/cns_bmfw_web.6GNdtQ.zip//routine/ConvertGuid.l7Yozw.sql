create
    definer = root@localhost function ConvertGuid(newGuid varchar(100), INSTR varchar(100)) returns varchar(100)
    sql security invoker
BEGIN

	DECLARE workStr varchar(100);

	set workStr = '';

	IF( INSTR is null) THEN

	return  '';

	END IF;

	IF( LENGTH(RTRIM(INSTR)) <= 12) THEN

	set workStr =  substr(newGuid, char_length(RTRIM(newGuid)) - 11, char_length(RTRIM(INSTR)));

	ELSE

	set workStr =  CONCAT(SUBSTR(INSTR, 1, char_length(RTRIM(INSTR)) - 12),SUBSTR(newGuid, char_length(RTRIM(newGuid)) - 11, 12));

	END IF;

	return  workStr;

END;


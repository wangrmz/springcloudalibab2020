create
    definer = root@localhost function sec_to_DHM(sec bigint) returns varchar(100)
begin

	return CONCAT(convert(TRUNCATE(sec/(24*60*60), 0), char), 'd ', convert(TRUNCATE((sec%(24*60*60))/(60*60), 0), char), 'h ', convert(TRUNCATE((sec%(60*60))/60, 0), char), 'm '); 

end;


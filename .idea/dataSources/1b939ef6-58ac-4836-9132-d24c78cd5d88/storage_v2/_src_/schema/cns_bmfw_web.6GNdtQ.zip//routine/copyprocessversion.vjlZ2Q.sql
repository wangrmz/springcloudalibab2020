create
    definer = root@localhost procedure copyprocessversion(IN FromProcessVersionGuid varchar(50),
                                                          IN ToProcessVersionGuid varchar(50), IN newGuid varchar(50))
    sql security invoker
BEGIN



    Insert Into workflow_activity  ( VmlID,ActivityGuid,ActivityType,ActivityName, ProcessVersionGuid,CopyFromActivityGuid, HandleURL,HandleBodyPageURL,SplitType,JoinType, IconX,IconY,Priority, CallSubProcessGuid,CallSubPVMethodGuid,SubProcessSyncType,TransactorInfo,MultiTransactorMode, Is_AllowWithdraw,Is_AllowAddAttachFile, AddAttachFileSource,Is_PassIfTransctorIsPresenter,Is_PassWhenNoTransactor, TimeLimitEnable,TimeLimit,TimeLimitUnit, EarlyWarning_Enable,EarlyWarning_Time,EarlyWarning_TimeUnit, EarlyWarningRemindType,EarlyWarningRemindContent,OverTimeRemindType, OverTimeRemindContent,OverTimeTransaction,Note, ApplicationConfig,SmsContent,OrderNum,ActivityDispName  ) select  VmlID,ConvertGuid(newGuid,ActivityGuid),ActivityType,ActivityName, ToProcessVersionGuid,ConvertGuid(newGuid,CopyFromActivityGuid), HandleURL,HandleBodyPageURL,SplitType,JoinType, IconX,IconY,Priority,CallSubProcessGuid,CallSubPVMethodGuid, SubProcessSyncType,TransactorInfo,MultiTransactorMode, Is_AllowWithdraw,Is_AllowAddAttachFile, '',NULL,NULL, TimeLimitEnable,TimeLimit,TimeLimitUnit, EarlyWarning_Enable,EarlyWarning_Time,EarlyWarning_TimeUnit, EarlyWarningRemindType,EarlyWarningRemindContent,OverTimeRemindType, OverTimeRemindContent,OverTimeTransaction,Note, ApplicationConfig,SmsContent,OrderNum,ActivityDispName from Workflow_Activity where ProcessVersionGuid=FromProcessVersionGuid;   

  

    Insert Into Workflow_Activity_FieldAccess ( RowGuid,ActivityMaterialGuid,MaterialGuid, ActivityGuid,TableID,FieldName, FieldChineseName,AccessRight,ProcessVersionGuid ) select  uuid(),ConvertGuid(newGuid,ActivityMaterialGuid),ConvertGuid(newGuid,MaterialGuid), ConvertGuid(newGuid,ActivityGuid),TableID,FieldName, FieldChineseName,AccessRight,ToProcessVersionGuid from Workflow_Activity_FieldAccess where ProcessVersionGuid=FromProcessVersionGuid;   

     

    Insert Into Workflow_Activity_LinkInfo ( LinkGuid,ActivityGuid,LinkName,OpenMode, OpenFeatures,LinkURL,LinkStyle,LinkClass, OrderNumber,ProcessVersionGuid ) select  uuid(),ConvertGuid(newGuid,ActivityGuid),LinkName,OpenMode, OpenFeatures,LinkURL,LinkStyle,LinkClass, OrderNumber,ToProcessVersionGuid from Workflow_Activity_LinkInfo where ProcessVersionGuid=FromProcessVersionGuid;     

     

    Insert Into Workflow_Activity_Material ( ActivityMaterialGuid,MaterialGuid,SubmitType, Is_MustSubmit,ActivityGuid,AccessRight,Is_AllowPrint, OrderNum,ProcessVersionGuid,MainPVGuid,MainPVActivityGuid ) select  ConvertGuid(newGuid,ActivityMaterialGuid),ConvertGuid(newGuid,MaterialGuid),SubmitType, Is_MustSubmit,ConvertGuid(newGuid,ActivityGuid),AccessRight,Is_AllowPrint, OrderNum,ToProcessVersionGuid,MainPVGuid,MainPVActivityGuid from Workflow_Activity_Material where ProcessVersionGuid=FromProcessVersionGuid;   

     

    Insert Into Workflow_Activity_Operation ( OperationGuid,ActivityGuid, OperationName,OperationType,OperationPageUrl, OrderNumber,TransitionGuid, OpenerPageUrlAfterOperate,OperationCommonPageUrl,DefaultOpinion, Note,Is_RequireOpinion,TargetActivity, Is_CheckMaterialSubmit,ProcessVersionGuid ) select  ConvertGuid(newGuid,OperationGuid),ConvertGuid(newGuid,ActivityGuid), OperationName,OperationType,OperationPageUrl, OrderNumber,ConvertGuid(newGuid,TransitionGuid), OpenerPageUrlAfterOperate,OperationCommonPageUrl,DefaultOpinion, Note,Is_RequireOpinion,ConvertGuidList(newGuid,TargetActivity), Is_CheckMaterialSubmit,ToProcessVersionGuid from Workflow_Activity_Operation where ProcessVersionGuid=FromProcessVersionGuid;   

     

    Insert Into Workflow_Config ( RowGuid,BelongTo,SourceGuid,ConfigName, ConfigValue,Note,ProcessVersionGuid ) select  uuid(),BelongTo,ConvertGuid(newGuid,SourceGuid),ConfigName, ConfigValue,Note,ToProcessVersionGuid from Workflow_Config where ProcessVersionGuid=FromProcessVersionGuid;    

     

    Insert Into Workflow_Context ( FieldGuid,BelongTo,ActivityGuid, FieldName,FieldType,FieldValue, ServerCode,ValueSource,FromMaterialGuid, FromMisTableID,FromFieldName,Note,ProcessVersionGuid ) select  uuid(),BelongTo,ConvertGuid(newGuid,ActivityGuid), FieldName,FieldType,FieldValue, ServerCode,ValueSource,ConvertGuid(newGuid,FromMaterialGuid), FromMisTableID,FromFieldName,Note,ToProcessVersionGuid from Workflow_Context where ProcessVersionGuid=FromProcessVersionGuid;   

     

    Insert Into Workflow_Event ( EventGuid,BelongTo,SourceGuid,EventName, EventType,EventMethodGuid, SyncType,Note,OrderNumber,ProcessVersionGuid ) select  uuid(),BelongTo, ConvertGuid(newGuid,SourceGuid),EventName, EventType,ConvertGuid(newGuid,EventMethodGuid), SyncType,Note,OrderNumber,ToProcessVersionGuid from Workflow_Event where ProcessVersionGuid=FromProcessVersionGuid;    

     

    Insert Into Workflow_InvokeMethod ( InvokeGuid,InvokeGroupGuid,MethodGuid, OrderNum,WhenThrowException,Is_Enabled, Note,ProcessVersionGuid ) select  uuid(),ConvertGuid(newGuid,InvokeGroupGuid),ConvertGuid(newGuid,MethodGuid), OrderNum,WhenThrowException,Is_Enabled, Note,ToProcessVersionGuid from Workflow_InvokeMethod where ProcessVersionGuid=FromProcessVersionGuid;    

     

    Insert Into Workflow_Method ( MethodGuid,BelongTo,ActivityGuid, DllPath,TypeName,MethodName,ReturnValueType, Note,Is_Log,ProcessVersionGuid ) select  ConvertGuid(newGuid,MethodGuid),BelongTo,ConvertGuid(newGuid,ActivityGuid), DllPath,TypeName,MethodName,ReturnValueType, Note,Is_Log,ToProcessVersionGuid from Workflow_Method where ProcessVersionGuid=FromProcessVersionGuid;   

     

    Insert Into Workflow_Method_Parameter ( MPGuid,MethodGuid,MPName, MPType,MPValue,Encrypt,ProcessVersionGuid ) select  uuid(),ConvertGuid(newGuid,MethodGuid),MPName, MPType,MPValue,Encrypt,ToProcessVersionGuid from Workflow_Method_Parameter where ProcessVersionGuid=FromProcessVersionGuid;     

     

    Insert Into Workflow_Participator ( ParticipatorGuid,SourceGuid,ParticipatorName,BelongTo, Type,DataID,BelongDept,MethodGuid,ModeType,ProcessVersionGuid ) select  uuid(),ConvertGuid(newGuid,SourceGuid),ParticipatorName,BelongTo, Type,DataID,BelongDept,ConvertGuid(newGuid,MethodGuid),ModeType,ToProcessVersionGuid from Workflow_Participator where ProcessVersionGuid=FromProcessVersionGuid;  

     

    Insert Into Workflow_PV_Material ( MaterialGuid,MaterialName,Status, Source,Type,PageUrl_ReadAndWrite,Template_ASInfoGroupGuid, Is_ShowInGrid,Is_InitMisTable,ClientTag,Note, SubmitType,ProcessVersionGuid,MainPVGuid,MainPVActivityGuid,FromMainPVMatGuid ) select  ConvertGuid(newGuid,MaterialGuid),MaterialName,Status, Source,Type,PageUrl_ReadAndWrite,'', Is_ShowInGrid,Is_InitMisTable,ClientTag,Note, SubmitType,ToProcessVersionGuid,MainPVGuid,MainPVActivityGuid,FromMainPVMatGuid from Workflow_PV_Material where ProcessVersionGuid=FromProcessVersionGuid;   

     

    Insert Into Workflow_PV_MisTableSet ( MisTableSetGuid,MaterialGuid,TableID, SQL_TableName,ProcessVersionGuid ) select  uuid(),ConvertGuid(newGuid,MaterialGuid),TableID, SQL_TableName,ToProcessVersionGuid from Workflow_PV_MisTableSet where ProcessVersionGuid=FromProcessVersionGuid;   

     

    Insert Into Workflow_PV_PrintAdapter ( RowGuid,FromMaterialGuidList,ToPrintTempleteGuid, PrintAdapterName,OrderNum,Note, Is_AddSQLTableName,ProcessVersionGuid ) select  uuid(),ConvertGuidList(newGuid,FromMaterialGuidList),ToPrintTempleteGuid, PrintAdapterName,OrderNum,Note, Is_AddSQLTableName,ToProcessVersionGuid from Workflow_PV_PrintAdapter where ProcessVersionGuid=FromProcessVersionGuid;     

     

    Insert Into Workflow_Transition ( TransitionGuid,TransitionName,Type,Is_ShowAsOperationButton, TransitionDispName,FromActivityGuid,ToActivityGuid, Point,Is_Default,Priority,PreWorkPageUrl,WorkPageUrl,AfterWorkPageUrl, WorkItemModeName,WorkItemNotifyType,WorkItemNotifyContent,TargetActivityTransactorSource, Is_TargetTransactor_Editable,SelectTransctorMethodGuid,VmlID, OrderNum,Is_SendToMessageCenter,ProcessVersionGuid ) select  ConvertGuid(newGuid,TransitionGuid),TransitionName,Type,Is_ShowAsOperationButton, TransitionDispName,ConvertGuid(newGuid,FromActivityGuid),ConvertGuid(newGuid,ToActivityGuid), Point,Is_Default,Priority,PreWorkPageUrl,WorkPageUrl,AfterWorkPageUrl, WorkItemModeName,WorkItemNotifyType,WorkItemNotifyContent,TargetActivityTransactorSource, Is_TargetTransactor_Editable,ConvertGuid(newGuid,SelectTransctorMethodGuid),VmlID, OrderNum,Is_SendToMessageCenter,ToProcessVersionGuid from Workflow_Transition where ProcessVersionGuid=FromProcessVersionGuid;    

     

Insert Into Workflow_Transition_Condition ( ConditionGuid,ConditionName,TransitionGuid, ConditionExpressionType,LeftValue,CompareOperation, RightValue,ConditionExpression,ValueType, MethodGuid,ProcessVersionGuid ) select  uuid(),ConditionName,ConvertGuid(newGuid,TransitionGuid), ConditionExpressionType,LeftValue,CompareOperation, RightValue,ConditionExpression,ValueType, ConvertGuid(newGuid,MethodGuid),ToProcessVersionGuid from Workflow_Transition_Condition where ProcessVersionGuid=FromProcessVersionGuid;    



END;


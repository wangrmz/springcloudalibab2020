create
    definer = root@localhost function selectAllUserCount() returns varchar(100) sql security invoker
BEGIN

	DECLARE rntstr varchar(500);

	DECLARE counts int;

	

	Select count(*) into counts FROM frame_user;



	RETURN CONCAT('mysql count :',counts);

END;


create
    definer = root@localhost procedure Table_Category_Add(IN categoryName varchar(100),
                                                          IN parentCategoryNum varchar(100),
                                                          IN HomePageUrl varchar(500)) sql security invoker
BEGIN

	DECLARE categoryNum varchar(100);

  DECLARE tempNum varchar(100);

	DECLARE tempNum1 varchar(100);

	DECLARE CONTINUE  HANDLER FOR SQLEXCEPTION,SQLWARNING,NOT FOUND 

  insert into Table_Category (categoryNum,categoryName, HomePageUrl) values (CONCAT(parentCategoryNum,'01'),categoryName, HomePageUrl);



	 IF (parentCategoryNum IS NULL) THEN

     select a.categoryNum INTO  tempNum from 

     (

           select  categoryNum  from Table_Category 

           where char_length(categoryNum)=2  

           order by categoryNum desc

     ) a  limit 1;  

  ELSE     

		select a.categoryNum INTO tempNum from 

    (

           select  categoryNum  from Table_Category 

           where SUBSTR(categoryNum,1,(char_length(categoryNum)-2))=parentCategoryNum 

           and char_length(categoryNum)=length(parentCategoryNum)+2  

           order by categoryNum desc

     ) a limit 1;

  END IF; 



	IF (tempNum IS NULL) THEN

      set categoryNum = CONCAT(parentCategoryNum,'01');

   ELSE

      BEGIN

          set tempNum1 = SUBSTR(tempNum,(char_length(tempNum)-1),2);

          set categoryNum = SUBSTR(tempNum,1,(char_length(tempNum)-2))|| cast(cast(tempNum1 as unsigned int)+1 as char);          

      END;

   END IF;   

   

   insert into Table_Category (categoryNum,categoryName, HomePageUrl) values (categoryNum,categoryName, HomePageUrl);



END;


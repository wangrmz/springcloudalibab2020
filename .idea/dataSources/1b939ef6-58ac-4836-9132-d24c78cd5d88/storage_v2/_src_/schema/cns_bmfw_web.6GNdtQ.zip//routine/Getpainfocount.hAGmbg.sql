create
    definer = root@localhost function Getpainfocount(UserGuid1 varchar(100), OUGuid1 varchar(100),
                                                     CategoryNum1 varchar(100), LimitType int, DType int,
                                                     WeekStartDate datetime, WeekEndDate datetime,
                                                     MonthStartDate datetime, MonthEndDate datetime) returns int
    sql security invoker
BEGIN

	DECLARE returnValue int;

	set returnValue=0;

	if(LimitType=0) then

   begin

      if(DType=1) then

    
      select count(InfoID) into returnValue from View_InfoMain where instr(categoryNum,CategoryNum1)=1 AND OUGuid=OUGuid1 AND UserGuid=UserGuid1 AND PubInWebDate BETWEEN WeekStartDate AND WeekEndDate;

    else

     
     select count(InfoID) into returnValue from View_InfoMain where instr(categoryNum,CategoryNum1)=1 AND OUGuid=OUGuid1 AND UserGuid=UserGuid1 AND PubInWebDate BETWEEN MonthStartDate AND MonthEndDate;

     

      end if;

   end;

elseif(LimitType=2) then

  begin

    if(DType=1) then

    
       select count(InfoID) into returnValue from View_InfoMain where instr(categoryNum,CategoryNum1)=1 AND UserGuid=UserGuid1 AND OUGuid=OUGuid1 AND PubInWebDate BETWEEN WeekStartDate AND WeekEndDate;



    else

     
       select count(InfoID) into returnValue from View_InfoMain where  instr(categoryNum,CategoryNum1)=1 AND UserGuid=UserGuid1 AND OUGuid=OUGuid1 AND PubInWebDate BETWEEN MonthStartDate AND MonthEndDate; 

     end if;

  end;

elseif(LimitType=3) then

  begin

    if(DType=1) then

      
     select count(InfoID) into returnValue from View_InfoMain where  instr(categoryNum,CategoryNum1)=1 AND UserGuid=UserGuid1 AND OUGuid=OUGuid1 AND PubInWebDate BETWEEN WeekStartDate AND WeekEndDate;

    else

      
      select count(InfoID) into returnValue from View_InfoMain where  instr(categoryNum,CategoryNum1)=1 AND UserGuid=UserGuid1 AND OUGuid=OUGuid1 AND PubInWebDate BETWEEN MonthStartDate AND MonthEndDate;

      end if;

  end;

end if;

return returnValue;

END;


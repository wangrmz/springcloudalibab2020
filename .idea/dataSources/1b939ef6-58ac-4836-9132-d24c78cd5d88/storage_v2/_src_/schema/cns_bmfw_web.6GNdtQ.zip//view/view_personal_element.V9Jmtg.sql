create definer = root@localhost view view_personal_element as
select `b`.`elementname`      AS `elementname`,
       `b`.`elementurl`       AS `elementurl`,
       `b`.`RowGuid`          AS `elementguid`,
       `b`.`IsDisable`        AS `elementdisable`,
       `a`.`ptrowguid`        AS `ptrowguid`,
       `a`.`isDisable`        AS `isdisable`,
       `a`.`userguid`         AS `userguid`,
       `c`.`elementlocation`  AS `initlocation`,
       `a`.`elementlocation`  AS `userlocation`,
       `c`.`belongportalguid` AS `belongportalguid`
from ((`cns_bmfw_web`.`personal_portal_element` `a` join `cns_bmfw_web`.`app_element` `b`) join `cns_bmfw_web`.`app_portal_element` `c`
      on (((`c`.`elementguid` = convert(`b`.`RowGuid` using utf8mb4)) and (`a`.`ptrowguid` = `c`.`rowguid`))));


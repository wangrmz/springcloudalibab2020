create definer = root@localhost view view_portal_myitem as
select `cns_bmfw_web`.`portal_myitem`.`ROWGUID`        AS `myrowguid`,
       `cns_bmfw_web`.`portal_myitem`.`USERGUID`       AS `userguid`,
       `cns_bmfw_web`.`portal_item`.`INITROW`          AS `initrow`,
       `cns_bmfw_web`.`portal_item`.`INITCOL`          AS `initcol`,
       `cns_bmfw_web`.`portal_item`.`rowspan`          AS `rowspan`,
       `cns_bmfw_web`.`portal_item`.`colspan`          AS `colspan`,
       `cns_bmfw_web`.`portal_item`.`belongportalguid` AS `belongportalguid`,
       `cns_bmfw_web`.`portal_item`.`TITLE`            AS `title`,
       `cns_bmfw_web`.`portal_item`.`ROWGUID`          AS `rowguid`,
       `cns_bmfw_web`.`portal_myitem`.`ITEMCOL`        AS `itemcol`,
       `cns_bmfw_web`.`portal_myitem`.`ITEMROW`        AS `itemrow`,
       `cns_bmfw_web`.`portal_myitem`.`rowspan`        AS `itemrowspan`,
       `cns_bmfw_web`.`portal_myitem`.`colspan`        AS `itemcolspan`,
       `cns_bmfw_web`.`portal_myitem`.`disabled`       AS `disabled`,
       `cns_bmfw_web`.`portal_item`.`url`              AS `url`
from (`cns_bmfw_web`.`portal_item` join `cns_bmfw_web`.`portal_myitem`
      on ((`cns_bmfw_web`.`portal_item`.`ROWGUID` = `cns_bmfw_web`.`portal_myitem`.`PORTALETGUID`)))
where (`cns_bmfw_web`.`portal_item`.`DISABLED` = 0);


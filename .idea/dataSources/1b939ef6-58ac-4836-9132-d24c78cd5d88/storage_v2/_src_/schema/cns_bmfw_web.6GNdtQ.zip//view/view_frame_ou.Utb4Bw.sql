create definer = root@localhost view view_frame_ou as
select `cns_bmfw_web`.`frame_ou`.`OUGUID`                    AS `Ouguid`,
       `cns_bmfw_web`.`frame_ou`.`OUCODE`                    AS `Oucode`,
       `cns_bmfw_web`.`frame_ou`.`OUNAME`                    AS `Ouname`,
       `cns_bmfw_web`.`frame_ou`.`OUSHORTNAME`               AS `Oushortname`,
       `cns_bmfw_web`.`frame_ou`.`ORDERNUMBER`               AS `Ordernumber`,
       `cns_bmfw_web`.`frame_ou`.`DESCRIPTION`               AS `Description`,
       `cns_bmfw_web`.`frame_ou`.`ADDRESS`                   AS `Address`,
       `cns_bmfw_web`.`frame_ou`.`POSTALCODE`                AS `Postalcode`,
       `cns_bmfw_web`.`frame_ou`.`TEL`                       AS `Tel`,
       `cns_bmfw_web`.`frame_ou`.`BASEOUGUID`                AS `Baseouguid`,
       `cns_bmfw_web`.`frame_ou`.`ISSUBWEBFLOW`              AS `Issubwebflow`,
       `cns_bmfw_web`.`frame_ou`.`PARENTOUGUID`              AS `Parentouguid`,
       `cns_bmfw_web`.`frame_ou`.`OUCODELEVEL`               AS `Oucodelevel`,
       `cns_bmfw_web`.`frame_ou`.`UPDATETIME`                AS `Updatetime`,
       `cns_bmfw_web`.`frame_ou`.`HASCHILDOU`                AS `Haschildou`,
       `cns_bmfw_web`.`frame_ou`.`HASCHILDUSER`              AS `Haschilduser`,
       `cns_bmfw_web`.`frame_ou_extendinfo`.`ISINDEPENDENCE` AS `Isindependence`
from (`cns_bmfw_web`.`frame_ou` join `cns_bmfw_web`.`frame_ou_extendinfo`)
where (`cns_bmfw_web`.`frame_ou`.`OUGUID` = `cns_bmfw_web`.`frame_ou_extendinfo`.`OUGUID`);


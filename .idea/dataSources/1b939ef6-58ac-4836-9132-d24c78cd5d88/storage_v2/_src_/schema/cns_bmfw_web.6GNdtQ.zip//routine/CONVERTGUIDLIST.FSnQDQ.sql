create
    definer = root@localhost function CONVERTGUIDLIST(newGuid varchar(100), INSTR varchar(100)) returns varchar(100)
    sql security invoker
BEGIN

	DECLARE RawStr text;

	DECLARE workStr text;

  DECLARE FromIndex int;

	DECLARE ToIndex int;



	set RawStr = INSTR;

	set workStr = '';

	set FromIndex = 1;

  set ToIndex = 1;

	

	set ToIndex = INSTR(RawStr,';');

	WHILE  ToIndex  >  0 

	do

		set workStr=CONCAT(workStr,CONVERTGUID( newGuid,SUBSTR(RawStr,FromIndex,ToIndex-1)),';');

		SET RawStr =SUBSTR(RawStr,ToIndex+1,CHAR_LENGTH(RawStr)-ToIndex);

		SET ToIndex = INSTR(RawStr,';');

    
	END WHILE;

	SET workStr = CONCAT(workStr,RawStr);

	return workStr;



	RETURN 0;

END;


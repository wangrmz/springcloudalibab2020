create definer = root@localhost view view_frame_user as
select `cns_bmfw_web`.`frame_user`.`USERGUID`            AS `UserGuid`,
       `cns_bmfw_web`.`frame_user`.`LOGINID`             AS `LoginID`,
       `cns_bmfw_web`.`frame_user`.`password`            AS `password`,
       `cns_bmfw_web`.`frame_user`.`OUGUID`              AS `OUGuid`,
       `cns_bmfw_web`.`frame_user`.`DISPLAYNAME`         AS `DisplayName`,
       `cns_bmfw_web`.`frame_user`.`ISENABLED`           AS `IsEnabled`,
       `cns_bmfw_web`.`frame_user`.`TITLE`               AS `Title`,
       `cns_bmfw_web`.`frame_user`.`LEADERGUID`          AS `LeaderGuid`,
       `cns_bmfw_web`.`frame_user`.`ORDERNUMBER`         AS `OrderNumber`,
       `cns_bmfw_web`.`frame_user`.`TELEPHONEOFFICE`     AS `TelephoneOffice`,
       `cns_bmfw_web`.`frame_user`.`MOBILE`              AS `Mobile`,
       `cns_bmfw_web`.`frame_user`.`EMAIL`               AS `Email`,
       `cns_bmfw_web`.`frame_user`.`DESCRIPTION`         AS `Description`,
       `cns_bmfw_web`.`frame_user`.`TELEPHONEHOME`       AS `TelephoneHome`,
       `cns_bmfw_web`.`frame_user`.`FAX`                 AS `Fax`,
       `cns_bmfw_web`.`frame_user`.`ALLOWUSEEMAIL`       AS `AllowUseEmail`,
       `cns_bmfw_web`.`frame_user`.`SEX`                 AS `Sex`,
       `cns_bmfw_web`.`frame_user`.`OUCODELEVEL`         AS `OUCodeLevel`,
       `cns_bmfw_web`.`frame_user_extendinfo`.`BIRTHDAY` AS `birthday`,
       `cns_bmfw_web`.`frame_user`.`UPDATETIME`          AS `UpDateTime`
from (`cns_bmfw_web`.`frame_user` join `cns_bmfw_web`.`frame_user_extendinfo`)
where (`cns_bmfw_web`.`frame_user`.`USERGUID` = `cns_bmfw_web`.`frame_user_extendinfo`.`USERGUID`);

